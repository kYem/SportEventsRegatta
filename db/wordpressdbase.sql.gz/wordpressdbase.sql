-- MySQL dump 10.13  Distrib 5.6.11, for Win32 (x86)
--
-- Host: localhost    Database: fyp
-- ------------------------------------------------------
-- Server version	5.6.11

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ku_action`
--

DROP TABLE IF EXISTS `ku_action`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ku_action` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `comment` text,
  `subject` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ku_action`
--

LOCK TABLES `ku_action` WRITE;
/*!40000 ALTER TABLE `ku_action` DISABLE KEYS */;
INSERT INTO `ku_action` VALUES (1,'create',NULL,NULL),(2,'read',NULL,NULL),(3,'update',NULL,NULL),(4,'delete',NULL,NULL),(5,'message',NULL,NULL),(6,'user',NULL,NULL),(7,'event','User can organise the event','EventRegistration'),(8,'assign','Assign user to the event',NULL),(9,'Member',NULL,NULL),(10,'Leader',NULL,NULL),(11,'Submitter',NULL,NULL),(12,'userGroup','userGroup also know as Team',NULL);
/*!40000 ALTER TABLE `ku_action` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ku_friendship`
--

DROP TABLE IF EXISTS `ku_friendship`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ku_friendship` (
  `inviter_id` int(11) NOT NULL,
  `friend_id` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `acknowledgetime` int(11) DEFAULT NULL,
  `requesttime` int(11) DEFAULT NULL,
  `updatetime` int(11) DEFAULT NULL,
  `message` varchar(255) NOT NULL,
  PRIMARY KEY (`inviter_id`,`friend_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ku_friendship`
--

LOCK TABLES `ku_friendship` WRITE;
/*!40000 ALTER TABLE `ku_friendship` DISABLE KEYS */;
INSERT INTO `ku_friendship` VALUES (1,4,2,1390152141,1390151944,1390151944,'Hi');
/*!40000 ALTER TABLE `ku_friendship` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ku_membership`
--

DROP TABLE IF EXISTS `ku_membership`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ku_membership` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `membership_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `payment_id` int(11) NOT NULL,
  `order_date` int(11) NOT NULL,
  `end_date` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `street` varchar(255) DEFAULT NULL,
  `zipcode` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `payment_date` int(11) DEFAULT NULL,
  `subscribed` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ku_membership`
--

LOCK TABLES `ku_membership` WRITE;
/*!40000 ALTER TABLE `ku_membership` DISABLE KEYS */;
INSERT INTO `ku_membership` VALUES (1,3,4,1,1390223339,1390831128,NULL,NULL,NULL,NULL,1390226328,0);
/*!40000 ALTER TABLE `ku_membership` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ku_message`
--

DROP TABLE IF EXISTS `ku_message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ku_message` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `timestamp` int(10) unsigned NOT NULL,
  `from_user_id` int(10) unsigned NOT NULL,
  `to_user_id` int(10) unsigned NOT NULL,
  `title` varchar(255) NOT NULL,
  `message` text,
  `message_read` tinyint(1) NOT NULL,
  `answered` tinyint(1) DEFAULT NULL,
  `draft` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ku_message`
--

LOCK TABLES `ku_message` WRITE;
/*!40000 ALTER TABLE `ku_message` DISABLE KEYS */;
INSERT INTO `ku_message` VALUES (1,1390151944,1,4,'New friendship request from admin','A new friendship request from admin has been made: Hi <a href=\"/FYP/friendship/friendship/index\">Manage my friends</a><br /><a href=\"/FYP/profile/profile/view\">To the profile</a>',1,NULL,NULL),(2,1390152141,4,1,'Your friendship request has been accepted','Your friendship request to admin has been accepted',1,NULL,NULL),(3,1390226328,1,4,'Payment arrived','The payment of order 1 has been arrived at 01-20-2014 14:58:48',1,NULL,NULL);
/*!40000 ALTER TABLE `ku_message` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ku_payment`
--

DROP TABLE IF EXISTS `ku_payment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ku_payment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `text` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ku_payment`
--

LOCK TABLES `ku_payment` WRITE;
/*!40000 ALTER TABLE `ku_payment` DISABLE KEYS */;
INSERT INTO `ku_payment` VALUES (1,'Prepayment',NULL),(2,'Paypal',NULL);
/*!40000 ALTER TABLE `ku_payment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ku_permission`
--

DROP TABLE IF EXISTS `ku_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ku_permission` (
  `principal_id` int(11) NOT NULL,
  `subordinate_id` int(11) NOT NULL DEFAULT '0',
  `type` enum('user','role') NOT NULL,
  `action` int(11) unsigned NOT NULL,
  `subaction` int(11) unsigned NOT NULL,
  `template` tinyint(1) NOT NULL,
  `comment` text,
  PRIMARY KEY (`principal_id`,`subordinate_id`,`type`,`action`,`subaction`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ku_permission`
--

LOCK TABLES `ku_permission` WRITE;
/*!40000 ALTER TABLE `ku_permission` DISABLE KEYS */;
INSERT INTO `ku_permission` VALUES (1,0,'user',6,1,1,''),(1,0,'role',6,2,0,'User Manager can read other users'),(1,6,'role',1,3,0,'UserManager Can create/update user'),(5,1,'role',7,1,0,'EventOrganiser can create the event'),(5,6,'role',7,8,0,''),(6,0,'role',1,3,0,'Team Manager can create and update users'),(6,7,'role',9,8,0,'Team leader can assign team member to the event'),(6,7,'role',12,1,0,'Team Manager can create user group'),(8,0,'role',7,3,0,'l');
/*!40000 ALTER TABLE `ku_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ku_privacysetting`
--

DROP TABLE IF EXISTS `ku_privacysetting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ku_privacysetting` (
  `user_id` int(10) unsigned NOT NULL,
  `message_new_friendship` tinyint(1) NOT NULL DEFAULT '1',
  `message_new_message` tinyint(1) NOT NULL DEFAULT '1',
  `message_new_profilecomment` tinyint(1) NOT NULL DEFAULT '1',
  `appear_in_search` tinyint(1) NOT NULL DEFAULT '1',
  `show_online_status` tinyint(1) NOT NULL DEFAULT '1',
  `log_profile_visits` tinyint(1) NOT NULL DEFAULT '1',
  `ignore_users` varchar(255) DEFAULT NULL,
  `public_profile_fields` bigint(15) unsigned DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ku_privacysetting`
--

LOCK TABLES `ku_privacysetting` WRITE;
/*!40000 ALTER TABLE `ku_privacysetting` DISABLE KEYS */;
INSERT INTO `ku_privacysetting` VALUES (0,1,1,1,1,1,1,'',NULL),(1,1,1,1,1,1,1,'',NULL),(2,1,1,1,1,1,1,NULL,NULL),(3,1,1,1,1,1,1,'',NULL),(4,1,1,1,1,1,1,'',NULL),(5,1,1,1,1,1,1,'',NULL),(6,1,1,1,1,1,1,'',NULL),(7,1,1,1,1,1,1,'',NULL),(8,1,1,1,1,1,1,'',NULL),(9,1,1,1,1,1,1,'',NULL),(10,1,1,1,1,1,1,'',NULL),(11,1,1,1,1,1,1,'',NULL),(12,1,1,1,1,1,1,'',NULL),(13,1,1,1,1,1,1,'',NULL),(14,1,1,1,1,1,1,'',NULL),(15,1,1,1,1,1,1,'',NULL),(16,1,1,1,1,1,1,'',NULL),(17,1,1,1,1,1,1,'',NULL),(18,1,1,1,1,1,1,'',NULL),(19,1,1,1,1,1,1,'',NULL);
/*!40000 ALTER TABLE `ku_privacysetting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ku_profile`
--

DROP TABLE IF EXISTS `ku_profile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ku_profile` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `lastname` varchar(50) NOT NULL DEFAULT '',
  `firstname` varchar(50) NOT NULL DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `street` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `about` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ku_profile`
--

LOCK TABLES `ku_profile` WRITE;
/*!40000 ALTER TABLE `ku_profile` DISABLE KEYS */;
INSERT INTO `ku_profile` VALUES (1,1,'Admin','Web','info@kyem.net','','',''),(2,2,'Smith','John','John@example.com','','',''),(3,3,'Jones','Graeme','','','Kingston','Client'),(4,4,'Manager','Tom','','','',''),(5,5,'Smith','Joe','','','',''),(6,6,'TT','Mike','','','',''),(7,7,'Kas','Kes','','','',''),(8,10,'Davison','Callum','e@mail.de','','',''),(9,15,'Cole','Alex','','','',''),(10,16,'Squire','Alek','','','',''),(11,17,'Soden','Alexander','','','',''),(12,18,'Moore','Alexander','','','',''),(13,19,'Mitchell','Barney','','','','');
/*!40000 ALTER TABLE `ku_profile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ku_profile_comment`
--

DROP TABLE IF EXISTS `ku_profile_comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ku_profile_comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `profile_id` int(11) NOT NULL,
  `comment` text NOT NULL,
  `createtime` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ku_profile_comment`
--

LOCK TABLES `ku_profile_comment` WRITE;
/*!40000 ALTER TABLE `ku_profile_comment` DISABLE KEYS */;
INSERT INTO `ku_profile_comment` VALUES (1,4,4,'cOMMent\r\n',1390220563);
/*!40000 ALTER TABLE `ku_profile_comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ku_profile_visit`
--

DROP TABLE IF EXISTS `ku_profile_visit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ku_profile_visit` (
  `visitor_id` int(11) NOT NULL,
  `visited_id` int(11) NOT NULL,
  `timestamp_first_visit` int(11) NOT NULL,
  `timestamp_last_visit` int(11) NOT NULL,
  `num_of_visits` int(11) NOT NULL,
  PRIMARY KEY (`visitor_id`,`visited_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ku_profile_visit`
--

LOCK TABLES `ku_profile_visit` WRITE;
/*!40000 ALTER TABLE `ku_profile_visit` DISABLE KEYS */;
INSERT INTO `ku_profile_visit` VALUES (1,3,1390219038,1390219038,1),(1,4,1390151906,1395716525,7),(1,5,1390256157,1390256157,1),(1,8,1390338816,1390351538,3),(1,10,1390339535,1390339535,1),(4,1,1390220519,1390220519,1),(4,2,1391989527,1391989527,1),(4,8,1390261234,1390261234,1),(4,9,1390261239,1390261239,1),(5,4,1390246832,1390253807,2),(5,7,1390252726,1390252740,2);
/*!40000 ALTER TABLE `ku_profile_visit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ku_rg_age`
--

DROP TABLE IF EXISTS `ku_rg_age`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ku_rg_age` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `organisation_id` int(11) DEFAULT NULL,
  `lower` float(3,1) DEFAULT NULL,
  `upper` float(3,1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `age_UNIQUE` (`name`),
  KEY `fk_organisationId_idx` (`organisation_id`),
  CONSTRAINT `fk_organisationId` FOREIGN KEY (`organisation_id`) REFERENCES `ku_rg_organisation` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ku_rg_age`
--

LOCK TABLES `ku_rg_age` WRITE;
/*!40000 ALTER TABLE `ku_rg_age` DISABLE KEYS */;
INSERT INTO `ku_rg_age` VALUES (8,'U12½ ',3,NULL,12.5),(9,'U14',3,12.5,14.0),(10,'U16',3,14.0,16.0),(11,'U18',3,16.0,18.0),(12,'Cadet',4,9.0,13.0),(13,'Ranger',4,13.0,18.0);
/*!40000 ALTER TABLE `ku_rg_age` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ku_rg_boat`
--

DROP TABLE IF EXISTS `ku_rg_boat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ku_rg_boat` (
  `id` tinyint(3) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `description` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name_UNIQUE` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ku_rg_boat`
--

LOCK TABLES `ku_rg_boat` WRITE;
/*!40000 ALTER TABLE `ku_rg_boat` DISABLE KEYS */;
INSERT INTO `ku_rg_boat` VALUES (1,'Dinghy',''),(2,'Gig',''),(3,'Kayak',''),(6,'Canoe','A canoe is a lightweight narrow boat, typically pointed at both ends and open on top, propelled by one or more seated or kneeling paddlers facing the direction of travel using a single-bladed paddle.');
/*!40000 ALTER TABLE `ku_rg_boat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ku_rg_event`
--

DROP TABLE IF EXISTS `ku_rg_event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ku_rg_event` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `star_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `min_participant` int(11) DEFAULT NULL,
  `max_participant` int(11) DEFAULT NULL,
  `age_id` int(11) DEFAULT NULL,
  `organisation_id` int(11) DEFAULT NULL,
  `seats` int(2) DEFAULT NULL,
  `status_id` tinyint(3) DEFAULT NULL,
  `filename` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name_UNIQUE` (`name`),
  KEY `fk_agegroup_idx` (`age_id`),
  KEY `fk_organisationId_idx` (`organisation_id`),
  KEY `status` (`status_id`),
  CONSTRAINT `fk_status` FOREIGN KEY (`status_id`) REFERENCES `ku_rg_status` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ku_rg_event`
--

LOCK TABLES `ku_rg_event` WRITE;
/*!40000 ALTER TABLE `ku_rg_event` DISABLE KEYS */;
INSERT INTO `ku_rg_event` VALUES (12,'U18 Dinghy','2013-10-01','2013-11-14',4,12,11,3,2,3,'uploads/Event/12.jpg'),(14,'U12 Dinghy','2013-10-15','2013-11-01',4,12,8,3,1,1,'uploads/Event/14.jpg'),(35,'U16 Kayak','2013-10-15','2013-11-01',4,16,10,3,1,2,NULL),(38,'U18 S/Gig ','2013-10-15','2013-11-01',4,16,11,3,1,3,NULL),(39,'Cadet S/Gig','2013-10-15','2013-11-01',4,24,12,4,1,1,NULL),(40,'U18 Gig','2013-10-15','2013-11-01',12,32,11,3,1,2,NULL),(41,'Rangers Kayak','2013-10-15','2014-01-01',2,16,13,4,4,3,NULL),(42,'U12 Kayak','2014-01-17','2014-01-30',2,24,8,3,1,5,NULL),(44,'U12 Gig','2014-01-17','2014-01-21',2,4,8,3,1,2,NULL),(45,'Ranger S/Dinghy','2014-01-14','2014-01-13',2,16,13,4,1,3,'uploads/Event/45.jpg'),(46,'U16 D/Dinghy','2014-01-01','2014-01-31',2,16,10,3,2,3,NULL),(47,'Under 12½ Gig Pulling','2014-01-15','2014-01-29',5,40,8,4,5,3,NULL),(50,'U12 S/Gig','2014-02-11','2014-02-18',4,17,8,3,2,1,'uploads/Event/50.jpg'),(51,'Ranger D/Dinghy','2014-02-11','2014-02-03',4,12,13,4,2,1,'uploads/Event/51.jpg');
/*!40000 ALTER TABLE `ku_rg_event` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ku_rg_event_boat`
--

DROP TABLE IF EXISTS `ku_rg_event_boat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ku_rg_event_boat` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `event_id` int(11) NOT NULL,
  `boat_id` tinyint(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_eventBoat_boat_id_idx` (`boat_id`),
  KEY `fk_eventBoat_event_id` (`event_id`),
  CONSTRAINT `fk_eventBoat_boat_id` FOREIGN KEY (`boat_id`) REFERENCES `ku_rg_boat` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_eventBoat_event_id` FOREIGN KEY (`event_id`) REFERENCES `ku_rg_event` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=290 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ku_rg_event_boat`
--

LOCK TABLES `ku_rg_event_boat` WRITE;
/*!40000 ALTER TABLE `ku_rg_event_boat` DISABLE KEYS */;
INSERT INTO `ku_rg_event_boat` VALUES (188,46,1),(203,44,2),(205,40,2),(207,47,2),(220,35,3),(225,42,3),(231,41,3),(239,39,2),(243,38,2),(259,50,2),(261,51,1),(281,45,1),(287,12,1),(289,14,1);
/*!40000 ALTER TABLE `ku_rg_event_boat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ku_rg_group_event`
--

DROP TABLE IF EXISTS `ku_rg_group_event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ku_rg_group_event` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) DEFAULT NULL,
  `event_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_group_id_idx` (`group_id`),
  KEY `fk_event_id_idx` (`event_id`),
  CONSTRAINT `fk_event_id` FOREIGN KEY (`event_id`) REFERENCES `ku_rg_event` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_group_id` FOREIGN KEY (`group_id`) REFERENCES `ku_usergroup` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=195 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ku_rg_group_event`
--

LOCK TABLES `ku_rg_group_event` WRITE;
/*!40000 ALTER TABLE `ku_rg_group_event` DISABLE KEYS */;
INSERT INTO `ku_rg_group_event` VALUES (190,2,14),(191,2,39),(192,2,50),(193,2,51),(194,1,39);
/*!40000 ALTER TABLE `ku_rg_group_event` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ku_rg_organisation`
--

DROP TABLE IF EXISTS `ku_rg_organisation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ku_rg_organisation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `organisation` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `organisation_UNIQUE` (`organisation`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ku_rg_organisation`
--

LOCK TABLES `ku_rg_organisation` WRITE;
/*!40000 ALTER TABLE `ku_rg_organisation` DISABLE KEYS */;
INSERT INTO `ku_rg_organisation` VALUES (4,'Sea Rangers'),(3,'Sea Scouts');
/*!40000 ALTER TABLE `ku_rg_organisation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ku_rg_status`
--

DROP TABLE IF EXISTS `ku_rg_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ku_rg_status` (
  `id` tinyint(3) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name_UNIQUE` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ku_rg_status`
--

LOCK TABLES `ku_rg_status` WRITE;
/*!40000 ALTER TABLE `ku_rg_status` DISABLE KEYS */;
INSERT INTO `ku_rg_status` VALUES (5,'Closed'),(2,'Initial Registration'),(1,'Not Active'),(3,'Open'),(4,'Running');
/*!40000 ALTER TABLE `ku_rg_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ku_rg_user_event`
--

DROP TABLE IF EXISTS `ku_rg_user_event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ku_rg_user_event` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `event_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_userEvent_event_id_idx` (`event_id`),
  KEY `fk_userEvent_user_id` (`user_id`),
  CONSTRAINT `fk_userEvent_event_id` FOREIGN KEY (`event_id`) REFERENCES `ku_rg_event` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_userEvent_user_id` FOREIGN KEY (`user_id`) REFERENCES `ku_user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ku_rg_user_event`
--

LOCK TABLES `ku_rg_user_event` WRITE;
/*!40000 ALTER TABLE `ku_rg_user_event` DISABLE KEYS */;
/*!40000 ALTER TABLE `ku_rg_user_event` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ku_role`
--

DROP TABLE IF EXISTS `ku_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ku_role` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `membership_priority` int(11) DEFAULT NULL,
  `price` double DEFAULT NULL COMMENT 'Price (when using membership module)',
  `duration` int(11) DEFAULT NULL COMMENT 'How long a membership is valid',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ku_role`
--

LOCK TABLES `ku_role` WRITE;
/*!40000 ALTER TABLE `ku_role` DISABLE KEYS */;
INSERT INTO `ku_role` VALUES (1,'UserManager','These users can manage Users',0,0,0),(2,'Demo','Users having the demo role',0,0,0),(5,'EventOrganiser','Event Organiser, can create events',NULL,NULL,NULL),(6,'TeamManager','Team manager can register team members to the competition',NULL,NULL,NULL),(7,'TeamMember','Team members can participate in the events and have access to the event schedule',NULL,NULL,NULL),(8,'ResultSubmiter','Can submit event results',NULL,NULL,NULL);
/*!40000 ALTER TABLE `ku_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ku_translation`
--

DROP TABLE IF EXISTS `ku_translation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ku_translation` (
  `message` varbinary(255) NOT NULL,
  `translation` varchar(255) NOT NULL,
  `language` varchar(5) NOT NULL,
  `category` varchar(255) NOT NULL,
  PRIMARY KEY (`message`,`language`,`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ku_translation`
--

LOCK TABLES `ku_translation` WRITE;
/*!40000 ALTER TABLE `ku_translation` DISABLE KEYS */;
/*!40000 ALTER TABLE `ku_translation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ku_user`
--

DROP TABLE IF EXISTS `ku_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ku_user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` char(64) CHARACTER SET latin1 NOT NULL,
  `activationKey` varchar(128) NOT NULL DEFAULT '',
  `createtime` int(11) NOT NULL DEFAULT '0',
  `lastvisit` int(11) NOT NULL DEFAULT '0',
  `lastaction` int(11) NOT NULL DEFAULT '0',
  `lastpasswordchange` int(11) NOT NULL DEFAULT '0',
  `failedloginattempts` int(11) NOT NULL DEFAULT '0',
  `superuser` int(1) NOT NULL DEFAULT '0',
  `status` int(1) NOT NULL DEFAULT '0',
  `avatar` varchar(255) DEFAULT NULL,
  `notifyType` enum('None','Digest','Instant','Threshold') DEFAULT 'Instant',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  KEY `status` (`status`),
  KEY `superuser` (`superuser`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ku_user`
--

LOCK TABLES `ku_user` WRITE;
/*!40000 ALTER TABLE `ku_user` DISABLE KEYS */;
INSERT INTO `ku_user` VALUES (1,'admin','$2a$13$C1.MY1xIP.dEfOBHlPJGx.tjzwMuZEEY9FnoBCILnwdvLZcZph.S.','',1388986884,1395685725,1395719333,1393449725,0,1,1,NULL,'Instant'),(2,'John15','$2a$13$vAVnjpZHIbNUvtZWqvis9efeeX7jzGJY0a5lYdnPb/Wd6Jc1qI9CW','',1388986885,0,0,0,0,0,1,NULL,'Instant'),(3,'Graeme','$2a$13$1HIfInviR4tcyMsvtxIpl.EhR.3x/cBaYeBrF9oq7oVbJIh9ukxNm','$2a$13$JslizbKkPNADbWFOkDSgBeOUcUR7E8F5SEOSsUZMcawOL9CSKM6.y',1388987563,0,0,1388987562,0,1,1,NULL,'Instant'),(4,'teammanager1','$2a$13$qal2Gq1lIVSZopjztl1mg.jCheRSGoOM630wbZPmTX9MhlEy6sFTC','$2a$13$Q.hSKLzUPxq1j/iiwUJAgObzMzqDqKc6oUlCi.JtyfUC6ELA2nkCK',1390151895,1393449702,1393449726,1390151893,0,0,1,NULL,'Instant'),(5,'usermanager','$2a$13$q4QlVEbKR9d9fTL/R/lN4epuPkWZr/AMyITjf4GbfSw/Rp3eb5R16','$2a$13$Zpiuj1lxdvTmNrZ2azff1.0M4tx7DAUo6Lnh3AF9KcqdWYQbWehfG',1390234962,1390237840,1390255654,1390234961,2,0,1,NULL,'Instant'),(6,'usermanager2','$2a$13$P6R16fnwG2zLLqKeAcbRQedDQgY0NCuoewv3fsTxJJmZImcS8Qpj6','$2a$13$HBmALTs/SxWZluds7zTCEuTe1Wbu6fYwZU1.7nOtpXDcug0qpVTMi',1390237307,1390256240,1390256299,1390256191,0,0,1,NULL,'Instant'),(7,'kYem','$2a$13$wDOF7/PrFJrOCjXnSo8qr.168lwbifkP3eScysmgTtNob.HPgXSGq','$2a$13$HMHstuOK0BaWprTl2tVWteCbbPMB9xpb474foeAQWUGYlZ169J67m',1390252717,1390341359,1390341360,1390339941,0,1,1,NULL,'Instant'),(10,'CallumnDavison','$2a$13$FD6i7nOQKtoKzMWEI0uBauNkCjrEeCbSboEhWngDQOjn1TSOTrBVq','',1390253358,1390339424,1390339692,1390338905,0,0,1,NULL,'Instant'),(11,'Demo_16675_1','$2a$13$95jwdxqf0jVIL7MzIzV5SeeGHhO7aEFSV06k5ca/qABrk4gZ5VTPm','',1390253359,0,0,1390253358,0,0,-1,NULL,'Instant'),(12,'Demo_48891_2','$2a$13$gifjKuSge9tcfI29dq96vusDtiYUNvTalY6thZKTRwSf2A71lnqdS','',1390253359,0,0,1390253359,0,0,-1,NULL,'Instant'),(13,'Demo_47141_3','$2a$13$QW7Ma/cv7bNd6dlvkIKizeQ4ZFItpFN7cSF1vbP0HD9J9EWUgRuL6','',1390253360,0,0,1390253359,0,0,-1,NULL,'Instant'),(14,'Demo_8715_4','$2a$13$fPHO09wLAcVExmh7zS.Tx.Z0ubYTLP2I5AMxUKXfxq0G/VYembFP2','',1390253361,0,0,1390253360,0,0,1,NULL,'Instant'),(15,'AlexCole','$2a$13$deDZpkhF0ncYYgz.oGWZVenZnCjE5btzH0.IIbb53cbIhHkwCrZdC','$2a$13$DB7yk3snZq20kyCQHb1Y4.6P0kGJtyc/4mh2Wz7uTphfwLhyK2eQ2',1390338973,1390339714,1390339764,1390338971,0,0,1,NULL,'Instant'),(16,'AlekSquire','$2a$13$4GV.a3EmDo9qqzC1SnihCO5nuD691Hbqz6c2KNK5c4IlyPdzQ9366','$2a$13$hRG5TAzeF3xAi5oSYq.QjumYWRnckYV0mJGS0EymIyzP5Ugi2Dy3W',1390339050,1390339780,1390339953,1390339049,0,0,1,NULL,'Instant'),(17,'AlexanderSoden','$2a$13$fru9HhcZLkcYiBeWHbqMJ.BCK4CB9LYtJsedqkGS/PiT2FHhjEPkm','$2a$13$KtVcR93zNIfF7KRPcfBuyufiXSmHU09kP3EFN6jbZNQ3xR2RtHjI2',1390351660,0,0,1390351658,0,0,1,NULL,'Instant'),(18,'AndrewMoore','$2a$13$oOEMncZ5RY6hvzMwjiTznucgwWAj0dKdMn1sLNu2ef/yEbfKQdpPa','$2a$13$5EEEt5fvgBl5W9Afc5t.l.Gx41TM3I36ks4rrAgBm2KGaJgb1HuQi',1391999684,0,0,1391999683,0,0,1,NULL,'Instant'),(19,'BarneyMitchell','$2a$13$jUwpO02wl0kpcCQ7tHm.0Odvc795HJWT3P26MBfa/ImYscvmp9efS','$2a$13$h3CEmngY/yPyEYNV2oLBiepx7fmq8.AymZ9ahYVIJmGq1kO2tfEc.',1391999742,0,0,1391999740,0,0,1,NULL,'Instant');
/*!40000 ALTER TABLE `ku_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ku_user_group_message`
--

DROP TABLE IF EXISTS `ku_user_group_message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ku_user_group_message` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `author_id` int(11) unsigned NOT NULL,
  `group_id` int(11) unsigned NOT NULL,
  `createtime` int(11) unsigned NOT NULL,
  `title` varchar(255) NOT NULL,
  `message` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ku_user_group_message`
--

LOCK TABLES `ku_user_group_message` WRITE;
/*!40000 ALTER TABLE `ku_user_group_message` DISABLE KEYS */;
INSERT INTO `ku_user_group_message` VALUES (1,4,1,1390152200,'Ajax Created','Created club ajax. Join');
/*!40000 ALTER TABLE `ku_user_group_message` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ku_user_role`
--

DROP TABLE IF EXISTS `ku_user_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ku_user_role` (
  `user_id` int(10) unsigned NOT NULL,
  `role_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`user_id`,`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ku_user_role`
--

LOCK TABLES `ku_user_role` WRITE;
/*!40000 ALTER TABLE `ku_user_role` DISABLE KEYS */;
INSERT INTO `ku_user_role` VALUES (3,5),(4,6),(5,1),(5,6),(6,1),(7,6),(8,7),(9,7),(10,7),(15,7),(16,7),(17,7),(18,7),(19,7);
/*!40000 ALTER TABLE `ku_user_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ku_usergroup`
--

DROP TABLE IF EXISTS `ku_usergroup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ku_usergroup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `owner_id` int(11) NOT NULL,
  `participants` text,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `organisation_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ku_usergroup`
--

LOCK TABLES `ku_usergroup` WRITE;
/*!40000 ALTER TABLE `ku_usergroup` DISABLE KEYS */;
INSERT INTO `ku_usergroup` VALUES (1,4,'[\"10\",\"15\",\"16\",\"17\",\"18\",\"19\"]','Ajax','Ajax Club is historically one of the most successful clubs in the world; according to the IFFHS, Ajax were the seventh most successful European club of the 20th century.[2] The club is one of the five teams that has earned the right to keep the European Cup and to wear a multiple-winner badge; they won consecutively in 1971–1973. In 1972, they completed the continental treble by winning the Eredivisie, KNVB Cup, and the European Cup.',3),(2,4,'[\"10\"]','Bournemouth','Bournemouth Regatta club',NULL),(3,1,'[\"1\"]','Fareham','Fareham /ˈfɛərəm/ is a market town at the north-west tip of Portsmouth Harbour, between the cities of Portsmouth and Southampton',3),(4,4,NULL,'Jaguar','Lorem ipsum dolor sit amet',3),(5,4,'','Leander','Lorem ipsum dolor sit amet',3),(6,4,NULL,'Lymington','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus venenatis cursus turpis, eget rutrum lorem. Donec sollicitudin nulla quis ornare feugiat. Etiam ultrices id justo at sagittis. Aenean dictum consequat arcu, vel commodo nisl rutrum sed.',3),(7,4,'[\"10\"]','Relentless','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus venenatis cursus turpis, eget rutrum lorem. Donec sollicitudin nulla quis ornare feugiat. Etiam ultrices id justo at sagittis. Aenean dictum consequat arcu, vel commodo nisl rutrum sed.',3),(8,4,NULL,'Sealion','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus venenatis cursus turpis, eget rutrum lorem. Donec sollicitudin nulla quis ornare feugiat. Etiam ultrices id justo at sagittis. Aenean dictum consequat arcu, vel commodo nisl rutrum sed.',3),(9,4,NULL,'Streatham','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus venenatis cursus turpis, eget rutrum lorem. Donec sollicitudin nulla quis ornare feugiat. Etiam ultrices id justo at sagittis. Aenean dictum consequat arcu, vel commodo nisl rutrum sed.',3),(10,4,NULL,'Viking','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus venenatis cursus turpis, eget rutrum lorem. Donec sollicitudin nulla quis ornare feugiat. Etiam ultrices id justo at sagittis. Aenean dictum consequat arcu, vel commodo nisl rutrum sed.',3),(11,4,NULL,'Warspite','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus venenatis cursus turpis, eget rutrum lorem. Donec sollicitudin nulla quis ornare feugiat. Etiam ultrices id justo at sagittis. Aenean dictum consequat arcu, vel commodo nisl rutrum sed.',3),(12,4,NULL,'Barnehurst','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus venenatis cursus turpis, eget rutrum lorem. Donec sollicitudin nulla quis ornare feugiat. Etiam ultrices id justo at sagittis. Aenean dictum consequat arcu, vel commodo nisl rutrum sed.',4),(13,4,NULL,'Frobisher','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus venenatis cursus turpis, eget rutrum lorem. Donec sollicitudin nulla quis ornare feugiat. Etiam ultrices id justo at sagittis. Aenean dictum consequat arcu, vel commodo nisl rutrum sed.',4),(14,4,NULL,'Mermaid','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus venenatis cursus turpis, eget rutrum lorem. Donec sollicitudin nulla quis ornare feugiat. Etiam ultrices id justo at sagittis. Aenean dictum consequat arcu, vel commodo nisl rutrum sed.',4),(15,4,NULL,'Vandyck','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus venenatis cursus turpis, eget rutrum lorem. Donec sollicitudin nulla quis ornare feugiat. Etiam ultrices id justo at sagittis. Aenean dictum consequat arcu, vel commodo nisl rutrum sed.',4),(16,4,NULL,'Wakeful','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus venenatis cursus turpis, eget rutrum lorem. Donec sollicitudin nulla quis ornare feugiat. Etiam ultrices id justo at sagittis. Aenean dictum consequat arcu, vel commodo nisl rutrum sed.',4),(17,4,NULL,'Waterwitch','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus venenatis cursus turpis, eget rutrum lorem. Donec sollicitudin nulla quis ornare feugiat. Etiam ultrices id justo at sagittis. Aenean dictum consequat arcu, vel commodo nisl rutrum sed.',4);
/*!40000 ALTER TABLE `ku_usergroup` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-03-25  3:51:55
