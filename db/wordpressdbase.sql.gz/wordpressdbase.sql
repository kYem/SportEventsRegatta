-- MySQL dump 10.13  Distrib 5.6.11, for Win32 (x86)
--
-- Host: localhost    Database: fyp
-- ------------------------------------------------------
-- Server version	5.6.11

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ku_action`
--

DROP TABLE IF EXISTS `ku_action`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ku_action` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `comment` text,
  `subject` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ku_action`
--

LOCK TABLES `ku_action` WRITE;
/*!40000 ALTER TABLE `ku_action` DISABLE KEYS */;
INSERT INTO `ku_action` VALUES (1,'create',NULL,NULL),(2,'read',NULL,NULL),(3,'update',NULL,NULL),(4,'delete',NULL,NULL),(5,'message',NULL,NULL),(6,'user',NULL,NULL),(7,'event','User can organise the event','EventRegistration'),(8,'assign','Assign user to the event',NULL),(9,'Member',NULL,NULL),(10,'Leader',NULL,NULL),(11,'Submitter',NULL,NULL),(12,'userGroup','userGroup also know as Team',NULL);
/*!40000 ALTER TABLE `ku_action` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ku_friendship`
--

DROP TABLE IF EXISTS `ku_friendship`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ku_friendship` (
  `inviter_id` int(11) NOT NULL,
  `friend_id` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `acknowledgetime` int(11) DEFAULT NULL,
  `requesttime` int(11) DEFAULT NULL,
  `updatetime` int(11) DEFAULT NULL,
  `message` varchar(255) NOT NULL,
  PRIMARY KEY (`inviter_id`,`friend_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ku_friendship`
--

LOCK TABLES `ku_friendship` WRITE;
/*!40000 ALTER TABLE `ku_friendship` DISABLE KEYS */;
INSERT INTO `ku_friendship` VALUES (1,4,2,1390152141,1390151944,1390151944,'Hi');
/*!40000 ALTER TABLE `ku_friendship` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ku_membership`
--

DROP TABLE IF EXISTS `ku_membership`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ku_membership` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `membership_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `payment_id` int(11) NOT NULL,
  `order_date` int(11) NOT NULL,
  `end_date` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `street` varchar(255) DEFAULT NULL,
  `zipcode` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `payment_date` int(11) DEFAULT NULL,
  `subscribed` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ku_membership`
--

LOCK TABLES `ku_membership` WRITE;
/*!40000 ALTER TABLE `ku_membership` DISABLE KEYS */;
INSERT INTO `ku_membership` VALUES (1,3,4,1,1390223339,1390831128,NULL,NULL,NULL,NULL,1390226328,0);
/*!40000 ALTER TABLE `ku_membership` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ku_message`
--

DROP TABLE IF EXISTS `ku_message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ku_message` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `timestamp` int(10) unsigned NOT NULL,
  `from_user_id` int(10) unsigned NOT NULL,
  `to_user_id` int(10) unsigned NOT NULL,
  `title` varchar(255) NOT NULL,
  `message` text,
  `message_read` tinyint(1) NOT NULL,
  `answered` tinyint(1) DEFAULT NULL,
  `draft` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ku_message`
--

LOCK TABLES `ku_message` WRITE;
/*!40000 ALTER TABLE `ku_message` DISABLE KEYS */;
INSERT INTO `ku_message` VALUES (1,1390151944,1,4,'New friendship request from admin','A new friendship request from admin has been made: Hi <a href=\"/FYP/friendship/friendship/index\">Manage my friends</a><br /><a href=\"/FYP/profile/profile/view\">To the profile</a>',1,NULL,NULL),(2,1390152141,4,1,'Your friendship request has been accepted','Your friendship request to admin has been accepted',1,NULL,NULL),(3,1390226328,1,4,'Payment arrived','The payment of order 1 has been arrived at 01-20-2014 14:58:48',1,NULL,NULL);
/*!40000 ALTER TABLE `ku_message` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ku_payment`
--

DROP TABLE IF EXISTS `ku_payment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ku_payment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `text` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ku_payment`
--

LOCK TABLES `ku_payment` WRITE;
/*!40000 ALTER TABLE `ku_payment` DISABLE KEYS */;
INSERT INTO `ku_payment` VALUES (1,'Prepayment',NULL),(2,'Paypal',NULL);
/*!40000 ALTER TABLE `ku_payment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ku_permission`
--

DROP TABLE IF EXISTS `ku_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ku_permission` (
  `principal_id` int(11) NOT NULL,
  `subordinate_id` int(11) NOT NULL DEFAULT '0',
  `type` enum('user','role') NOT NULL,
  `action` int(11) unsigned NOT NULL,
  `subaction` int(11) unsigned NOT NULL,
  `template` tinyint(1) NOT NULL,
  `comment` text,
  PRIMARY KEY (`principal_id`,`subordinate_id`,`type`,`action`,`subaction`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ku_permission`
--

LOCK TABLES `ku_permission` WRITE;
/*!40000 ALTER TABLE `ku_permission` DISABLE KEYS */;
INSERT INTO `ku_permission` VALUES (1,0,'user',6,1,1,''),(5,1,'role',7,1,0,'EventOrganiser can create the event'),(5,6,'role',7,8,0,''),(6,7,'role',9,8,0,'Team leader can assign team member to the event'),(6,7,'role',12,1,0,'Team Manager can create user group'),(8,0,'role',7,3,0,'l');
/*!40000 ALTER TABLE `ku_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ku_privacysetting`
--

DROP TABLE IF EXISTS `ku_privacysetting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ku_privacysetting` (
  `user_id` int(10) unsigned NOT NULL,
  `message_new_friendship` tinyint(1) NOT NULL DEFAULT '1',
  `message_new_message` tinyint(1) NOT NULL DEFAULT '1',
  `message_new_profilecomment` tinyint(1) NOT NULL DEFAULT '1',
  `appear_in_search` tinyint(1) NOT NULL DEFAULT '1',
  `show_online_status` tinyint(1) NOT NULL DEFAULT '1',
  `log_profile_visits` tinyint(1) NOT NULL DEFAULT '1',
  `ignore_users` varchar(255) DEFAULT NULL,
  `public_profile_fields` bigint(15) unsigned DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ku_privacysetting`
--

LOCK TABLES `ku_privacysetting` WRITE;
/*!40000 ALTER TABLE `ku_privacysetting` DISABLE KEYS */;
INSERT INTO `ku_privacysetting` VALUES (0,1,1,1,1,1,1,'',NULL),(1,1,1,1,1,1,1,'',NULL),(2,1,1,1,1,1,1,NULL,NULL),(3,1,1,1,1,1,1,'',NULL),(4,1,1,1,1,1,1,'',NULL),(5,1,1,1,1,1,1,'',NULL),(6,1,1,1,1,1,1,'',NULL),(7,1,1,1,1,1,1,'',NULL),(8,1,1,1,1,1,1,'',NULL),(9,1,1,1,1,1,1,'',NULL),(10,1,1,1,1,1,1,'',NULL),(11,1,1,1,1,1,1,'',NULL),(12,1,1,1,1,1,1,'',NULL),(13,1,1,1,1,1,1,'',NULL),(14,1,1,1,1,1,1,'',NULL),(15,1,1,1,1,1,1,'',NULL),(16,1,1,1,1,1,1,'',NULL),(17,1,1,1,1,1,1,'',NULL),(18,1,1,1,1,1,1,'',NULL),(19,1,1,1,1,1,1,'',NULL),(20,1,1,1,1,1,1,'',NULL),(21,1,1,1,1,1,1,'',NULL),(22,1,1,1,1,1,1,'',NULL),(23,1,1,1,1,1,1,'',NULL),(24,1,1,1,1,1,1,'',NULL),(25,1,1,1,1,1,1,'',NULL),(26,1,1,1,1,1,1,'',NULL),(27,1,1,1,1,1,1,'',NULL),(28,1,1,1,1,1,1,'',NULL),(29,1,1,1,1,1,1,'',NULL),(30,1,1,1,1,1,1,'',NULL),(31,1,1,1,1,1,1,'',NULL),(32,1,1,1,1,1,1,'',NULL),(33,1,1,1,1,1,1,'',NULL),(34,1,1,1,1,1,1,'',NULL),(35,1,1,1,1,1,1,'',NULL),(36,1,1,1,1,1,1,'',NULL),(37,1,1,1,1,1,1,'',NULL),(38,1,1,1,1,1,1,'',NULL),(39,1,1,1,1,1,1,'',NULL),(40,1,1,1,1,1,1,'',NULL),(41,1,1,1,1,1,1,'',NULL),(42,1,1,1,1,1,1,'',NULL),(43,1,1,1,1,1,1,'',NULL),(44,1,1,1,1,1,1,'',NULL),(45,1,1,1,1,1,1,'',NULL);
/*!40000 ALTER TABLE `ku_privacysetting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ku_profile`
--

DROP TABLE IF EXISTS `ku_profile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ku_profile` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `lastname` varchar(50) NOT NULL DEFAULT '',
  `firstname` varchar(50) NOT NULL DEFAULT '',
  `dob` date DEFAULT NULL,
  `email` varchar(255) NOT NULL DEFAULT '',
  `street` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `about` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ku_profile`
--

LOCK TABLES `ku_profile` WRITE;
/*!40000 ALTER TABLE `ku_profile` DISABLE KEYS */;
INSERT INTO `ku_profile` VALUES (1,1,'Kasiulynas','Kestutis','1990-01-17','info@kyem.net','','',''),(2,2,'Smith','John','1982-02-05','John@ajax.com','','',''),(3,3,'Jones','Graeme','1974-04-04','','','Kingston','Client'),(4,4,'Maner','Tom','1977-01-19','','','',''),(5,5,'Smith','Joe','1978-12-12','','','',''),(6,6,'TT','Mike','1981-03-18','','','',''),(7,7,'Kas','Kes','1990-01-17','','','',''),(8,10,'Davison','Callum','1999-12-21','e@mail.de','','',''),(9,15,'Cole','Alex','2001-10-04','','','',''),(10,16,'Squire','Alek','2002-03-13','','','',''),(11,17,'Soden','Alexander','1990-06-09','','','',''),(12,18,'Moore','Alexander','1996-07-20','','','',''),(13,19,'Mitchell','Barney','1998-10-12','','','',''),(14,20,'Bartholamew','Dan ','1997-08-15','Bartholamew@kingston.co.uk','','Kingston',''),(15,21,'Crook','Abi','1974-04-04','','','',''),(16,22,'Flatt','Chris','1975-05-12','','','',''),(17,23,'Pryke','Curtis','1984-01-17','','','',''),(18,24,'Mitcheison','Dylan','1970-01-17','','','',''),(19,25,'Nash','Elise','1984-06-15','','','',''),(20,26,'Ridge','George','1975-05-12','','','',''),(21,27,'Radford','Harry','1975-02-12','','','',''),(22,28,'Pryke','Francesca','1985-05-12','','','',''),(23,29,'Slater','Jennifer','1980-01-22','','','',''),(24,30,'Mansell','Rachel','1975-12-12','','','',''),(25,31,'Wilson','Dane','1990-10-15','','','',''),(26,34,'Goodman','Gus','2001-10-07','','','',''),(27,35,'Carrow','Henry','1990-07-17','','','',''),(28,36,'Barnett','Jack','1998-03-29','','','',''),(29,37,'Simpson','James','1996-03-26','','','',''),(30,38,'Dunn','Joe','1998-08-24','','','London',''),(31,39,'Farmer','Joe','1996-06-11','','','',''),(32,40,'Mackie','Kirsty','1995-08-05','','','',''),(33,41,'Barnett','Luke','2000-03-17','','','',''),(34,42,'Wilson','Marcus','2001-03-02','','','',''),(35,43,'Davison','Miky','1998-07-07','','','',''),(36,44,'Niall  ','O\'Callaghan','1997-01-05','','','',''),(37,45,'Johannsen','Ziggy','2001-08-07','','','','');
/*!40000 ALTER TABLE `ku_profile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ku_profile_comment`
--

DROP TABLE IF EXISTS `ku_profile_comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ku_profile_comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `profile_id` int(11) NOT NULL,
  `comment` text NOT NULL,
  `createtime` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ku_profile_comment`
--

LOCK TABLES `ku_profile_comment` WRITE;
/*!40000 ALTER TABLE `ku_profile_comment` DISABLE KEYS */;
INSERT INTO `ku_profile_comment` VALUES (1,4,4,'cOMMent\r\n',1390220563);
/*!40000 ALTER TABLE `ku_profile_comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ku_profile_visit`
--

DROP TABLE IF EXISTS `ku_profile_visit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ku_profile_visit` (
  `visitor_id` int(11) NOT NULL,
  `visited_id` int(11) NOT NULL,
  `timestamp_first_visit` int(11) NOT NULL,
  `timestamp_last_visit` int(11) NOT NULL,
  `num_of_visits` int(11) NOT NULL,
  PRIMARY KEY (`visitor_id`,`visited_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ku_profile_visit`
--

LOCK TABLES `ku_profile_visit` WRITE;
/*!40000 ALTER TABLE `ku_profile_visit` DISABLE KEYS */;
INSERT INTO `ku_profile_visit` VALUES (1,3,1390219038,1395801731,2),(1,4,1390151906,1395716525,7),(1,5,1390256157,1390256157,1),(1,8,1390338816,1390351538,3),(1,10,1390339535,1390339535,1),(1,19,1395803031,1395803031,1),(4,1,1390220519,1390220519,1),(4,2,1391989527,1391989527,1),(4,8,1390261234,1390261234,1),(4,9,1390261239,1390261239,1),(5,4,1390246832,1390253807,2),(5,7,1390252726,1390252740,2);
/*!40000 ALTER TABLE `ku_profile_visit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ku_rg_age`
--

DROP TABLE IF EXISTS `ku_rg_age`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ku_rg_age` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `organisation_id` int(11) DEFAULT NULL,
  `lower` float(3,1) DEFAULT NULL,
  `upper` float(3,1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `age_UNIQUE` (`name`),
  KEY `fk_organisationId_idx` (`organisation_id`),
  CONSTRAINT `fk_organisationId` FOREIGN KEY (`organisation_id`) REFERENCES `ku_rg_organisation` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ku_rg_age`
--

LOCK TABLES `ku_rg_age` WRITE;
/*!40000 ALTER TABLE `ku_rg_age` DISABLE KEYS */;
INSERT INTO `ku_rg_age` VALUES (8,'U12½ ',3,NULL,12.5),(9,'U14',3,12.5,14.0),(10,'U16',3,14.0,16.0),(11,'U18',3,16.0,18.0),(12,'Cadet',4,9.0,13.0),(13,'Ranger',4,13.0,18.0);
/*!40000 ALTER TABLE `ku_rg_age` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ku_rg_boat`
--

DROP TABLE IF EXISTS `ku_rg_boat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ku_rg_boat` (
  `id` tinyint(3) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `description` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name_UNIQUE` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ku_rg_boat`
--

LOCK TABLES `ku_rg_boat` WRITE;
/*!40000 ALTER TABLE `ku_rg_boat` DISABLE KEYS */;
INSERT INTO `ku_rg_boat` VALUES (1,'Dinghy',''),(2,'Gig',''),(3,'Kayak',''),(6,'Canoe','A canoe is a lightweight narrow boat, typically pointed at both ends and open on top, propelled by one or more seated or kneeling paddlers facing the direction of travel using a single-bladed paddle.');
/*!40000 ALTER TABLE `ku_rg_boat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ku_rg_event`
--

DROP TABLE IF EXISTS `ku_rg_event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ku_rg_event` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `star_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `min_participant` int(11) DEFAULT NULL,
  `max_participant` int(11) DEFAULT NULL,
  `age_id` int(11) DEFAULT NULL,
  `organisation_id` int(11) DEFAULT NULL,
  `seats` int(2) DEFAULT NULL,
  `status_id` tinyint(3) DEFAULT NULL,
  `filename` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name_UNIQUE` (`name`),
  KEY `fk_agegroup_idx` (`age_id`),
  KEY `fk_organisationId_idx` (`organisation_id`),
  KEY `status` (`status_id`),
  CONSTRAINT `fk_status` FOREIGN KEY (`status_id`) REFERENCES `ku_rg_status` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ku_rg_event`
--

LOCK TABLES `ku_rg_event` WRITE;
/*!40000 ALTER TABLE `ku_rg_event` DISABLE KEYS */;
INSERT INTO `ku_rg_event` VALUES (12,'U18 Dinghy','2013-10-01','2013-11-14',4,12,11,3,2,4,'uploads/Event/12.jpg'),(14,'U12 Dinghy','2013-10-15','2013-11-01',4,12,8,3,1,4,'uploads/Event/14.jpg'),(35,'U16 Kayak','2013-10-15','2013-11-01',4,16,10,3,1,4,NULL),(38,'U18 S/Gig ','2013-10-15','2013-11-01',4,16,11,3,1,4,NULL),(39,'Cadet S/Gig','2013-10-15','2013-11-01',4,24,12,4,1,4,NULL),(40,'U18 Gig','2013-10-15','2013-11-01',12,32,11,3,1,4,NULL),(41,'Rangers Kayak','2013-10-15','2014-01-01',2,16,13,4,4,4,NULL),(42,'U12 Kayak','2014-01-17','2014-01-30',2,24,8,3,1,4,NULL),(44,'U12 Gig','2014-01-17','2014-01-21',2,4,8,3,1,4,NULL),(45,'Ranger S/Dinghy','2014-01-14','2014-01-13',2,16,13,4,1,4,'uploads/Event/45.jpg'),(46,'U16 D/Dinghy','2014-01-01','2014-01-31',2,16,10,3,2,4,NULL),(47,'Under 12½ Gig Pulling','2014-01-15','2014-01-29',5,40,8,4,5,4,NULL),(50,'U12 S/Gig','2014-02-11','2014-02-18',4,17,8,3,2,4,'uploads/Event/50.jpg'),(51,'Ranger D/Dinghy','2014-02-11','2014-02-03',4,12,13,4,2,4,'uploads/Event/51.jpg');
/*!40000 ALTER TABLE `ku_rg_event` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ku_rg_event_boat`
--

DROP TABLE IF EXISTS `ku_rg_event_boat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ku_rg_event_boat` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `event_id` int(11) NOT NULL,
  `boat_id` tinyint(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_eventBoat_boat_id_idx` (`boat_id`),
  KEY `fk_eventBoat_event_id` (`event_id`),
  CONSTRAINT `fk_eventBoat_boat_id` FOREIGN KEY (`boat_id`) REFERENCES `ku_rg_boat` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_eventBoat_event_id` FOREIGN KEY (`event_id`) REFERENCES `ku_rg_event` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=290 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ku_rg_event_boat`
--

LOCK TABLES `ku_rg_event_boat` WRITE;
/*!40000 ALTER TABLE `ku_rg_event_boat` DISABLE KEYS */;
INSERT INTO `ku_rg_event_boat` VALUES (188,46,1),(203,44,2),(205,40,2),(207,47,2),(220,35,3),(225,42,3),(231,41,3),(239,39,2),(243,38,2),(259,50,2),(261,51,1),(281,45,1),(287,12,1),(289,14,1);
/*!40000 ALTER TABLE `ku_rg_event_boat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ku_rg_group_event`
--

DROP TABLE IF EXISTS `ku_rg_group_event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ku_rg_group_event` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) DEFAULT NULL,
  `event_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_group_id_idx` (`group_id`),
  KEY `fk_event_id_idx` (`event_id`),
  CONSTRAINT `fk_event_id` FOREIGN KEY (`event_id`) REFERENCES `ku_rg_event` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_group_id` FOREIGN KEY (`group_id`) REFERENCES `ku_usergroup` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=344 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ku_rg_group_event`
--

LOCK TABLES `ku_rg_group_event` WRITE;
/*!40000 ALTER TABLE `ku_rg_group_event` DISABLE KEYS */;
INSERT INTO `ku_rg_group_event` VALUES (249,2,14),(250,2,35),(251,2,38),(252,2,40),(253,2,50),(254,3,44),(302,9,14),(303,9,35),(304,9,40),(305,9,42),(318,12,39),(319,12,41),(320,12,45),(321,12,47),(322,12,51),(332,5,35),(338,1,12),(339,1,14),(340,1,38),(341,1,42),(342,1,44),(343,1,46);
/*!40000 ALTER TABLE `ku_rg_group_event` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ku_rg_organisation`
--

DROP TABLE IF EXISTS `ku_rg_organisation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ku_rg_organisation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `organisation` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `organisation_UNIQUE` (`organisation`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ku_rg_organisation`
--

LOCK TABLES `ku_rg_organisation` WRITE;
/*!40000 ALTER TABLE `ku_rg_organisation` DISABLE KEYS */;
INSERT INTO `ku_rg_organisation` VALUES (4,'Sea Rangers'),(3,'Sea Scouts');
/*!40000 ALTER TABLE `ku_rg_organisation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ku_rg_status`
--

DROP TABLE IF EXISTS `ku_rg_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ku_rg_status` (
  `id` tinyint(3) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name_UNIQUE` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ku_rg_status`
--

LOCK TABLES `ku_rg_status` WRITE;
/*!40000 ALTER TABLE `ku_rg_status` DISABLE KEYS */;
INSERT INTO `ku_rg_status` VALUES (2,'Initial Registration'),(1,'Not Active'),(3,'Open'),(4,'Running');
/*!40000 ALTER TABLE `ku_rg_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ku_rg_team`
--

DROP TABLE IF EXISTS `ku_rg_team`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ku_rg_team` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `group_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_group_id_idx` (`group_id`),
  KEY `fk_team_user_id_idx` (`user_id`),
  CONSTRAINT `fk_team_group_id` FOREIGN KEY (`group_id`) REFERENCES `ku_usergroup` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_team_user_id` FOREIGN KEY (`user_id`) REFERENCES `ku_user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=76 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ku_rg_team`
--

LOCK TABLES `ku_rg_team` WRITE;
/*!40000 ALTER TABLE `ku_rg_team` DISABLE KEYS */;
INSERT INTO `ku_rg_team` VALUES (12,5,15),(51,15,7),(52,19,7),(57,17,7),(58,20,7),(59,18,7),(60,31,7),(61,10,1),(62,16,1),(63,35,1),(64,34,1),(65,42,1),(66,38,1),(67,40,1),(68,37,1),(69,36,1),(70,41,1),(71,44,1),(72,39,1),(73,43,1),(74,43,1),(75,45,1);
/*!40000 ALTER TABLE `ku_rg_team` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ku_rg_user_event`
--

DROP TABLE IF EXISTS `ku_rg_user_event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ku_rg_user_event` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `event_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_userEvent_event_id_idx` (`event_id`),
  KEY `fk_userEvent_user_id` (`user_id`),
  CONSTRAINT `fk_userEvent_event_id` FOREIGN KEY (`event_id`) REFERENCES `ku_rg_event` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_userEvent_user_id` FOREIGN KEY (`user_id`) REFERENCES `ku_user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=69 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ku_rg_user_event`
--

LOCK TABLES `ku_rg_user_event` WRITE;
/*!40000 ALTER TABLE `ku_rg_user_event` DISABLE KEYS */;
INSERT INTO `ku_rg_user_event` VALUES (2,10,40),(3,2,40),(4,16,40),(25,38,12),(26,40,12),(27,37,12),(28,36,12),(47,10,14),(48,16,14),(49,35,14),(50,34,14),(51,42,14),(52,38,14),(53,40,14),(54,37,14),(55,36,14),(56,41,14),(58,37,38),(60,16,42),(62,16,44),(66,10,46),(67,38,46),(68,36,46);
/*!40000 ALTER TABLE `ku_rg_user_event` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ku_role`
--

DROP TABLE IF EXISTS `ku_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ku_role` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `membership_priority` int(11) DEFAULT NULL,
  `price` double DEFAULT NULL COMMENT 'Price (when using membership module)',
  `duration` int(11) DEFAULT NULL COMMENT 'How long a membership is valid',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ku_role`
--

LOCK TABLES `ku_role` WRITE;
/*!40000 ALTER TABLE `ku_role` DISABLE KEYS */;
INSERT INTO `ku_role` VALUES (5,'Event Organiser','Event Organiser, can create events',NULL,NULL,NULL),(6,'Group Leader','Group Leaders can register team members to the competition',NULL,NULL,NULL),(7,'Group Member','Team members can participate in the events and have access to the event schedule',NULL,NULL,NULL),(8,'Result Submitter','Can submit event results',NULL,NULL,NULL);
/*!40000 ALTER TABLE `ku_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ku_translation`
--

DROP TABLE IF EXISTS `ku_translation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ku_translation` (
  `message` varbinary(255) NOT NULL,
  `translation` varchar(255) NOT NULL,
  `language` varchar(5) NOT NULL,
  `category` varchar(255) NOT NULL,
  PRIMARY KEY (`message`,`language`,`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ku_translation`
--

LOCK TABLES `ku_translation` WRITE;
/*!40000 ALTER TABLE `ku_translation` DISABLE KEYS */;
/*!40000 ALTER TABLE `ku_translation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ku_user`
--

DROP TABLE IF EXISTS `ku_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ku_user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` char(64) CHARACTER SET latin1 NOT NULL,
  `activationKey` varchar(128) NOT NULL DEFAULT '',
  `createtime` int(11) NOT NULL DEFAULT '0',
  `lastvisit` int(11) NOT NULL DEFAULT '0',
  `lastaction` int(11) NOT NULL DEFAULT '0',
  `lastpasswordchange` int(11) NOT NULL DEFAULT '0',
  `failedloginattempts` int(11) NOT NULL DEFAULT '0',
  `superuser` int(1) NOT NULL DEFAULT '0',
  `status` int(1) NOT NULL DEFAULT '0',
  `avatar` varchar(255) DEFAULT NULL,
  `notifyType` enum('None','Digest','Instant','Threshold') DEFAULT 'Instant',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  KEY `status` (`status`),
  KEY `superuser` (`superuser`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ku_user`
--

LOCK TABLES `ku_user` WRITE;
/*!40000 ALTER TABLE `ku_user` DISABLE KEYS */;
INSERT INTO `ku_user` VALUES (1,'admin','$2a$13$C1.MY1xIP.dEfOBHlPJGx.tjzwMuZEEY9FnoBCILnwdvLZcZph.S.','',1388986884,1395769902,1396121053,1393449725,0,1,1,NULL,'Instant'),(2,'JohnSmith','$2a$13$hFt7Z31KvJJCqHOXVfdyRuPRN382CxLVSdX0rurteDTkCRkZrH/4.','',1388986885,0,0,1395770042,0,0,1,NULL,'Instant'),(3,'Graeme','$2a$13$1HIfInviR4tcyMsvtxIpl.EhR.3x/cBaYeBrF9oq7oVbJIh9ukxNm','$2a$13$JslizbKkPNADbWFOkDSgBeOUcUR7E8F5SEOSsUZMcawOL9CSKM6.y',1388987563,0,0,1388987562,0,1,1,NULL,'Instant'),(4,'TomM','$2a$13$L3kDpF.I0SW9h6nzrDcqe.C0YY88Fb3bgARKyMyiB51s4So56MyQK','$2a$13$Q.hSKLzUPxq1j/iiwUJAgObzMzqDqKc6oUlCi.JtyfUC6ELA2nkCK',1390151895,1395769841,1395769893,1395770006,0,0,1,NULL,'Instant'),(5,'JoeSmith','$2a$13$K/kLCDZAsdf6JzAFFGN0MeNhTnEYY5gri8j2FIqhjUrPlAa266wI.','$2a$13$Zpiuj1lxdvTmNrZ2azff1.0M4tx7DAUo6Lnh3AF9KcqdWYQbWehfG',1390234962,1395971593,1395976398,1395769974,0,0,1,NULL,'Instant'),(6,'MikeTT','$2a$13$Wx4.Ydq/bDnJl25h4du3ouxFq0R76qhy4wu9QpKoa532p5WH/UicO','$2a$13$HBmALTs/SxWZluds7zTCEuTe1Wbu6fYwZU1.7nOtpXDcug0qpVTMi',1390237307,1390256240,1390256299,1395769931,0,0,1,NULL,'Instant'),(7,'kYem','$2a$13$wDOF7/PrFJrOCjXnSo8qr.168lwbifkP3eScysmgTtNob.HPgXSGq','$2a$13$HMHstuOK0BaWprTl2tVWteCbbPMB9xpb474foeAQWUGYlZ169J67m',1390252717,1395949636,1395876381,1390339941,0,0,1,NULL,'Instant'),(10,'CallumnDavison','$2a$13$CJiUmuD2U3dLvqql37BEXevSiYkgL1AgdrffpfD3fxUaYct9MNAIK','',1390253358,1395876599,1395880101,1395876562,0,0,1,NULL,'Instant'),(15,'AlexCole','$2a$13$deDZpkhF0ncYYgz.oGWZVenZnCjE5btzH0.IIbb53cbIhHkwCrZdC','$2a$13$DB7yk3snZq20kyCQHb1Y4.6P0kGJtyc/4mh2Wz7uTphfwLhyK2eQ2',1390338973,1390339714,1390339764,1390338971,0,0,1,NULL,'Instant'),(16,'AlekSquire','$2a$13$4GV.a3EmDo9qqzC1SnihCO5nuD691Hbqz6c2KNK5c4IlyPdzQ9366','$2a$13$hRG5TAzeF3xAi5oSYq.QjumYWRnckYV0mJGS0EymIyzP5Ugi2Dy3W',1390339050,1390339780,1390339953,1390339049,0,0,1,NULL,'Instant'),(17,'AlexanderSoden','$2a$13$fru9HhcZLkcYiBeWHbqMJ.BCK4CB9LYtJsedqkGS/PiT2FHhjEPkm','$2a$13$KtVcR93zNIfF7KRPcfBuyufiXSmHU09kP3EFN6jbZNQ3xR2RtHjI2',1390351660,0,0,1390351658,0,0,1,NULL,'Instant'),(18,'AndrewMoore','$2a$13$oOEMncZ5RY6hvzMwjiTznucgwWAj0dKdMn1sLNu2ef/yEbfKQdpPa','$2a$13$5EEEt5fvgBl5W9Afc5t.l.Gx41TM3I36ks4rrAgBm2KGaJgb1HuQi',1391999684,0,0,1391999683,0,0,1,NULL,'Instant'),(19,'BarneyMitchell','$2a$13$jUwpO02wl0kpcCQ7tHm.0Odvc795HJWT3P26MBfa/ImYscvmp9efS','$2a$13$h3CEmngY/yPyEYNV2oLBiepx7fmq8.AymZ9ahYVIJmGq1kO2tfEc.',1391999742,0,0,1391999740,0,0,1,NULL,'Instant'),(20,'DanBartholamew','$2a$13$xcHqFgag3W1SckE5NbbfZe6DxS.X.pmwC6VAU.tDLJbCBsSUKq5iC','$2a$13$xrwNvhZHxHuABu.DWMFzaeeVUjqoQJXSOIxkwG/uOF9aT56Ge/BG2',1395806311,1395876519,1395876529,1395806310,0,0,1,NULL,'Instant'),(21,'AbiCrook','$2a$13$a0wVkPI33jVDwY5wcsg.0e6tVcobUjerEKgZ4FX8Rxly8/7RMTC6O','$2a$13$psZiN4FYafF9txAikY5iEu2j/9pGRiVH33sI9.G2kM0EEmLPrBdS.',1395887175,0,0,1395887174,0,0,1,NULL,'Instant'),(22,'ChrisFlatt','$2a$13$GkWReJGpwE2RKS7CtTtPNuKgf0ft/HnIGjgceCB1E4AITUb2IcVaG','$2a$13$TkwgGOSCyaeIsLb1EfUj5.BLkJvpDWvrLl8ydZLWpMkVvuDC/4BDe',1395887236,0,0,1395887235,0,0,1,NULL,'Instant'),(23,'CurtisPryke','$2a$13$8p5z/JflI18h7KBT8qDYN.MRskqa0h7u3nzb4Y2/tbS0Wd0zml3HO','$2a$13$NG32LM7WRh857fyxM455I.mr2Y5BOHbeACQX41GXEaOd0zuJGtU9O',1395887313,0,0,1395887312,0,0,1,NULL,'Instant'),(24,'DylanMitcheison','$2a$13$ej1QI.H4CcHJoYFEBAb69e9cwGSOa.Jz/PX/.elS3LR9FNE/V5zUS','$2a$13$nEWCy3wbeH3Nawuh1k2fjOW2KYxBUludY4lwil1nnHFKb1e59MDpC',1395887362,0,0,1395887361,0,0,1,NULL,'Instant'),(25,'EliseNash','$2a$13$9I.dLpB5pZG6U1VSiTDRcOombhrb0Dq4bS1.UWOZpsid72bxpfy0C','$2a$13$HlBM8plVff916KgU5JyHKOHoTfO2Dd6eSN0GMw7GRlzVaKMJmRvJO',1395887417,0,0,1395887416,0,0,1,NULL,'Instant'),(26,'GeorgeRidge','$2a$13$OB0dgszEb74IxMSnef5Vjuh2UJ9mp2WLp4iQMzxQ5EcyOCnzdAEDa','$2a$13$lfHgASzwzJe3x7lpFjgUOuSHfShGeUbU0dCujt6ioyJT1UZhT38dS',1395887461,0,0,1395887460,0,0,1,NULL,'Instant'),(27,'HarryRadford','$2a$13$BUV.i6X1.XaZ0WfQ/HpwiuyAj70kzo5wSvsNIYVQRea5jmgoMacKm','$2a$13$zbnUW3Q3t1uOAF.GtIizZeNrYUDwODdLZz2khYdd/yKBqKufDUOgO',1395887531,0,0,1395887530,0,0,1,NULL,'Instant'),(28,'FrancescaPryke','$2a$13$BIJEf/hYxmecte/VOov2CuubHr7v9cxgvoNciM2lA4uS7DiUZpdES','$2a$13$NycsFs2/wdM9ixZ6VhTPIeJ3.FSQVGj1tvg/cN0xacWTCRoN9oVCG',1395887586,0,0,1395887585,0,0,1,NULL,'Instant'),(29,'JenniferSlater','$2a$13$t0aCmsH3LMmn6.DuK1pisuS62c3na7KrElFFZKLhqoCTrZfvgLiyi','$2a$13$fiMvWoHHO.lUIpdO4aJVkOZBGFL4QU7Kq9qxGlJphLAhIE2rFtzIC',1395887633,0,0,1395887631,0,0,1,NULL,'Instant'),(30,'RachelMansell','$2a$13$CFGCRwWaQ96EqXf8YfelXOw5hgoHvTXBrnfHbXetrlIs7MWALrjcO','$2a$13$oL7RT6g0duQegX/yBaX70.aDwLxb2mGM4vnhnNd2ekOFW2ETAfrtS',1395887683,0,0,1395887682,0,0,1,NULL,'Instant'),(31,'DaneWilson','$2a$13$7NgpDdSLN1CiWYZpgFIJI.W6NcnV5.JeCmDhafXc9Chz6X/MU4P3S','$2a$13$5nZ68ATR8C.crdV3kxi9SOtWiJu64DyH7cb8xYvplgoa6D33YV1Uy',1395892932,0,0,1395892931,0,0,1,NULL,'Instant'),(32,'kestutis1','$2a$13$NVDtfEL7ttOzh43sE1z6l.dUBYkaoU6Tvsc8fOfRcP0PClOVPmaVC','$2a$13$W..iaB56typaCXIxc05BmOKcn.OMxlNTy6VyQisFgaJevLwWiAgfK',1395957731,0,0,1395957730,0,0,-1,NULL,'Instant'),(33,'timTom','$2a$13$yBkGyV/ZO4LIEUw.458O2eP.lDtrA8IhVCURuwi.vXZzvgAfrKrn2','$2a$13$oEsfkM9l647vSexuk4SktewJyhm26gN2Nc2zPoiOztpNwwiO9ZKpu',1395957920,0,0,1395957919,0,0,-1,NULL,'Instant'),(34,'GusGoodman','$2a$13$LsfzCYElyfNWEVlDHKwCVuONj9ExgZ8Z9N9atO3rrXTPC.9Q37i3C','$2a$13$3w8W1fb5elVJ5cRiS03kC.PMIQFc73bARtLI1DC0uNhdgIaJKoFca',1395958212,0,0,1395958210,0,0,1,NULL,'Instant'),(35,'HenryCarrow','$2a$13$trkXvSPRpcTPpfOyiG6IK.Ta4VQfQrNQz8z0gZj2.wPTPSa1GN76O','$2a$13$5I7AsYGV6HQF..5HdiwLj.1B31/sQzkGq0hp79EKBwz1kI3NEyUVW',1395958269,0,0,1395958267,0,0,1,NULL,'Instant'),(36,'JackBarnett','$2a$13$7kypU7E/Q/FGYBuxswvXX.ulGISKD3dGQQbK0.TYDBFesLp/zG24G','$2a$13$G6zmzS9T7y9hFsXsX8PJvuyf3PmqE06rUugaeXFOq/Eg.YzMlXgz.',1395958382,0,0,1395958381,0,0,1,NULL,'Instant'),(37,'JamesSimpson','$2a$13$ayGgIJALA5PsT8d6UYX4bO4p2h5tdVz0ThI35t3OWo1yi51QH71fK','$2a$13$WUV1YKQGnZpscWNOYQEebuRbJZf4Li4S27R5O.OsCC96tB0Ba4FgC',1395958723,0,0,1395958721,0,0,1,NULL,'Instant'),(38,'JoeDunn','$2a$13$o7FktQ5XQPS8CRUKnoB8Y.W.45ARrA5FCpmG6Ha2Xw0SEp8sUq/Ym','$2a$13$QItd2pEp0n6tZDRcR8K9dujtPvMPeAmsGRKjXiXZogix.V5IMFjBy',1395958779,0,0,1395958778,0,0,1,NULL,'Instant'),(39,'JoeFarmer','$2a$13$R1ORnKFCZvpqJi4/sJY5yOkPz6MUvZNo76citwpb3UbliFY7hbWlq','$2a$13$CSQmx7LTk0js3twrZKvCb.eidrK/lXr6.llLSFluiiRI2Q0DwlBXW',1395959090,0,0,1395959089,0,0,1,NULL,'Instant'),(40,'KirstyMackie','$2a$13$2O1DDNj75KbY/ZcB6vfk0Oz/wfPSEPiC47JXw8y0JID9zv12aDNei','$2a$13$bz4zQ866E4EAFDYJuuX28.coU96h5ksrg8yzlbuWK6WEWbVEsJeXm',1395959207,0,0,1395959206,0,0,1,NULL,'Instant'),(41,'LukeBarnett','$2a$13$Ui4ePgy1xGPDisC.B8ge2esk4kDJPDKcfPJMgfxEitZSNWNkMkZke','$2a$13$sUGcAnEjDWZKPrkeTfELYOdUjIetgX7m.NWQfnGi1kWlRDRkruCKq',1395959304,0,0,1395959303,0,0,1,NULL,'Instant'),(42,'MarcusWilson','$2a$13$.HMKVdLLWCQyEaXvHKIw6OWhYAJvp0bWOjJReMPH.3G49U1vdXoBq','$2a$13$ESSpHSKsyhpTAz5KAt0lD.7bH9y.NmrcOJmrBSIaAZ4z3YOx/0fea',1395961164,0,0,1395961163,0,0,1,NULL,'Instant'),(43,'MikyDavison','$2a$13$LMXcm0DFIxDFXgLNSQ9dS.v/Ab4BpWgTSyJcLixchSGBrL/pfFAWC','$2a$13$/x.oNTjqCgM95o0qZNodPupXM6VP/xHg/ZxT73cah.CFdetxBIlMG',1395961215,0,0,1395961214,0,0,1,NULL,'Instant'),(44,'NiallCallaghan','$2a$13$pZGezl1AK2TJN2TsNoVI2OpjsmpMpjhOEWdy9x4x7fXUjrj0ZfpAe','$2a$13$PiBCll9yvzt1YipkYuVFyOg4B8K6sy.3wc/sglf4kHYHHeCwosYUC',1395961318,0,0,1395961317,0,0,1,NULL,'Instant'),(45,'ZiggyJohannsen','$2a$13$I0jRdedEZqnbi9Hv2t1mz.GfhOOk/0fYfuqTKSZ3H9AmL/2A5j1LG','$2a$13$WS13tSuoe7nP/RvchjwhSeMVHns42jOyJYKC6FeT7ShAvqycpWnbG',1395961370,0,0,1395961369,0,0,1,NULL,'Instant');
/*!40000 ALTER TABLE `ku_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ku_user_group_message`
--

DROP TABLE IF EXISTS `ku_user_group_message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ku_user_group_message` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `author_id` int(11) unsigned NOT NULL,
  `group_id` int(11) unsigned NOT NULL,
  `createtime` int(11) unsigned NOT NULL,
  `title` varchar(255) NOT NULL,
  `message` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ku_user_group_message`
--

LOCK TABLES `ku_user_group_message` WRITE;
/*!40000 ALTER TABLE `ku_user_group_message` DISABLE KEYS */;
INSERT INTO `ku_user_group_message` VALUES (1,4,1,1390152200,'Ajax Created','Created club ajax. Join');
/*!40000 ALTER TABLE `ku_user_group_message` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ku_user_role`
--

DROP TABLE IF EXISTS `ku_user_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ku_user_role` (
  `user_id` int(10) unsigned NOT NULL,
  `role_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`user_id`,`role_id`),
  KEY `fk_role_id` (`role_id`),
  CONSTRAINT `fk_role_id` FOREIGN KEY (`role_id`) REFERENCES `ku_role` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ku_user_role`
--

LOCK TABLES `ku_user_role` WRITE;
/*!40000 ALTER TABLE `ku_user_role` DISABLE KEYS */;
INSERT INTO `ku_user_role` VALUES (3,5),(7,5),(2,6),(4,6),(5,6),(6,6),(20,6),(21,6),(22,6),(23,6),(24,6),(25,6),(26,6),(27,6),(28,6),(29,6),(30,6),(32,6),(8,7),(9,7),(10,7),(15,7),(16,7),(17,7),(18,7),(19,7),(20,7),(31,7),(34,7),(35,7),(36,7),(37,7),(38,7),(39,7),(40,7),(41,7),(42,7),(43,7),(44,7),(45,7);
/*!40000 ALTER TABLE `ku_user_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ku_usergroup`
--

DROP TABLE IF EXISTS `ku_usergroup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ku_usergroup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `owner_id` int(11) NOT NULL,
  `participants` text,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `organisation_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `owner_id` (`owner_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ku_usergroup`
--

LOCK TABLES `ku_usergroup` WRITE;
/*!40000 ALTER TABLE `ku_usergroup` DISABLE KEYS */;
INSERT INTO `ku_usergroup` VALUES (1,5,'[\"10\",\"15\",\"16\",\"17\",\"18\",\"19\"]','Ajax','Ajax Club is historically one of the most successful clubs in the world; according to the IFFHS, Ajax were the seventh most successful European club of the 20th century.[2] The club is one of the five teams that has earned the right to keep the European Cup and to wear a multiple-winner badge; they won consecutively in 1971–1973. In 1972, they completed the continental treble by winning the Eredivisie, KNVB Cup, and the European Cup.',3),(2,20,'[\"10\",\"17\"]','Bournemouth','Bournemouth Regatta club',3),(3,25,'[\"1\"]','Fareham','Fareham /ˈfɛərəm/ is a market town at the north-west tip of Portsmouth Harbour, between the cities of Portsmouth and Southampton',3),(4,21,NULL,'Jaguar','Lorem ipsum dolor sit amet',3),(5,15,'','Leander','Lorem ipsum dolor sit amet',3),(6,4,NULL,'Lymington','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus venenatis cursus turpis, eget rutrum lorem. Donec sollicitudin nulla quis ornare feugiat. Etiam ultrices id justo at sagittis. Aenean dictum consequat arcu, vel commodo nisl rutrum sed.',3),(7,27,'[\"10\"]','Relentless','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus venenatis cursus turpis, eget rutrum lorem. Donec sollicitudin nulla quis ornare feugiat. Etiam ultrices id justo at sagittis. Aenean dictum consequat arcu, vel commodo nisl rutrum sed.',3),(8,23,NULL,'Sealion','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus venenatis cursus turpis, eget rutrum lorem. Donec sollicitudin nulla quis ornare feugiat. Etiam ultrices id justo at sagittis. Aenean dictum consequat arcu, vel commodo nisl rutrum sed.',3),(9,22,NULL,'Streatham','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus venenatis cursus turpis, eget rutrum lorem. Donec sollicitudin nulla quis ornare feugiat. Etiam ultrices id justo at sagittis. Aenean dictum consequat arcu, vel commodo nisl rutrum sed.',3),(12,28,NULL,'Barnehurst','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus venenatis cursus turpis, eget rutrum lorem. Donec sollicitudin nulla quis ornare feugiat. Etiam ultrices id justo at sagittis. Aenean dictum consequat arcu, vel commodo nisl rutrum sed.',4),(13,30,NULL,'Frobisher','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus venenatis cursus turpis, eget rutrum lorem. Donec sollicitudin nulla quis ornare feugiat. Etiam ultrices id justo at sagittis. Aenean dictum consequat arcu, vel commodo nisl rutrum sed.',4),(14,29,NULL,'Mermaid','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus venenatis cursus turpis, eget rutrum lorem. Donec sollicitudin nulla quis ornare feugiat. Etiam ultrices id justo at sagittis. Aenean dictum consequat arcu, vel commodo nisl rutrum sed.',4),(15,24,NULL,'Vandyck','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus venenatis cursus turpis, eget rutrum lorem. Donec sollicitudin nulla quis ornare feugiat. Etiam ultrices id justo at sagittis. Aenean dictum consequat arcu, vel commodo nisl rutrum sed.',4);
/*!40000 ALTER TABLE `ku_usergroup` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-03-29 21:40:35
